  <!-- /.content-wrapper -->
  <footer class="main-footer" style="margin-left: 0 !important; width: 100% !important; padding: 1rem 1rem !important;">
    <div class="float-right d-none d-sm-inline">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2025 <a href="#" style="color:#FF4F9D;">TIFESS</a>.</strong> 
    Kelompok 6 ProWeb KOMA 25 TI USU
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../assets/plugins/bootstrap4/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../assets/dist/js/adminlte.min.js"></script>

</body>
</html>
